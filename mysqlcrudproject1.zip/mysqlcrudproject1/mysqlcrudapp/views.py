from django.shortcuts import render,redirect
from mysqlcrudapp.forms import UserForm
from django.http import HttpResponse
from mysqlcrudapp.models import user

# Create your views here.
def insert(request):
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponse('<h2>Data Inserted into DataBase</h2>')
    else:
        form = UserForm()
    return render(request,'index.html',{'form':form})

def show(request):
    users = user.objects.all()
    return render(request,'show.html',{'users':users})

def delete(request,id):
    User = user.objects.get(id=id)
    User.delete()
    return redirect('/show')

def edit(request,id):
    User = user.objects.get(id=id)
    return render(request,'edit.html',{'User':User})

def update(request,id):
    User = user.objects.get(id=id)
    form = UserForm(request.POST,instance=User)
    if form.is_valid():
        form.save()
        return redirect('/show')
    return render(request,'edit.html',{'form':form})

